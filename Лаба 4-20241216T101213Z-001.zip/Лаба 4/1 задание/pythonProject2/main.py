import math
import datetime

num = int(input())
sqrt_num = math.sqrt(num)
print(f"Квадратный корень числа {num} равен {sqrt_num}")

now = datetime.datetime.now()
print(f"Текущая дата и время: {now}")