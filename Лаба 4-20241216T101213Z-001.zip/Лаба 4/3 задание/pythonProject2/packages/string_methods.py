def counting_letters(s):
    vowels = 'aeiouAEIOU'
    return sum(1 for letter in s if letter in vowels)

def capitalizing_string(s):
    return s.upper()

def reversing_string(s):
    return s[::-1]

