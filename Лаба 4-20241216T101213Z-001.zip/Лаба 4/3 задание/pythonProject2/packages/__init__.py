print("__init__packages")

from .math_operators import *
from .string_methods import *