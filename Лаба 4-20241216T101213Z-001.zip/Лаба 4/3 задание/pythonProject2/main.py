from packages import *


print(add(5, 3))
print(subtract(10, 7))
print(multiply(4, 6))
print(divide(8, 2))
print(divide(8, 0), "\n")

print(reversing_string("hello"))
print(capitalizing_string("python"))
print(counting_letters("hello world"))