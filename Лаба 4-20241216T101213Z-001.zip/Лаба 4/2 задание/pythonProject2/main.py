import my_module


print("Введите a и b: ")
result = my_module.sum_func(int(input()), int(input()))
print(result) # Выведет 15, так как 5 + 10 = 15