                 #1
# def greet(name):
#     return (f"Hello {name}. Nice to meet you!")
#
# print(greet("Alex"))
                 #2
# def square(number):
#     return number * number
# print(square(16))
                 #3
# def max_of_two(x, y):
#     if x == y:
#         return "Числа равны"
#     return max(x, y)
#
# print(max_of_two(10, 6))
                 # 4
# def describe_person(name, age=30):
#     return (f"Your name is {name} and you are {age}")
#
# print(describe_person("Alex"))
                 # 5
# def is_prime(number):
#     for i in range(2, int(number ** 0.5)+1):
#         if number % i == 0:
#             return False
#     return True
# print(is_prime(3))
# print(is_prime(521))
# print(is_prime(512))

