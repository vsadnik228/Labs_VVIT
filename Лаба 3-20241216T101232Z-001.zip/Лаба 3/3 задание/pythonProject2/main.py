def read_file(file_name, method='whole'):
    try:
        with open(file_name, 'r') as file:
            if method == 'whole':
                content = file.read()
                print(content)
            elif method == 'line':
                for line in file:
                    print(line.strip())
    except FileNotFoundError:
        print("Такого файла не существует, проверьте название.")


Name_of_file = input("Введите название файла: ")
# Пример вызова функции для чтения всего файла
read_file(Name_of_file, 'whole')

print('')
# Пример вызова функции для построчного чтения файла
read_file(Name_of_file, 'line')
