Meeting = input("Введите текст, который хотите добавить в файл: ")
if len(Meeting) >= 1:
    with open("user_input.txt", "w") as file:
        file.write(Meeting)

    with open("user_input.txt", "r") as file:
        print(file.readline())

    while True:
        Contin = input("Если хотите добавить текст, напишите его: ")
        if len(Contin) >= 1:
            with open("user_input.txt", "a") as file:
                file.write(Contin)

            with open("user_input.txt", "r") as file:
                print("Измененный файл: ", sep="\n")
                print(file.readline())
        else:
            print("By ;)")
            break
else:
    print("Пустой ввод :( ")